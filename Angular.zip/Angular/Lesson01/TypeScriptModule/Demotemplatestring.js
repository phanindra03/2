var ename = "TypeScript";
var greeting = "Hello, " + ename + "! Your name has " + ename.length + " characters";
console.log(greeting);
